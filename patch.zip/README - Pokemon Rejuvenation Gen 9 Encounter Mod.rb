### Pokemon Rejuvenation Gen 9 Encounters Mod
### Created by Iracy

Ver. 0.1

TODO: 
- Add ways and locations to obtain all items introduced by gen 9 and this mod.
        - Currently, a handful of them, such as evolution items, are given to the player at Magrodar Crater.
- Add Wo-Chien, Chien-Pau, Ting-Lu, Chi-You, Koraidon, Miraidon, Okidoki, Munkidori, Fezandipiti, Ogerpon, Terapagos, Pecharunt.
        - These are planned to be added as Static Encounters and not Shadow Pokémon.


Thanks:
Huge thanks to Jan and the Pokemon Rejuvenation team for creating such an amazing game.
Special thanks to Alemi, Mat(Jarred), AsN, 2ndCatch, Sapphiada and Tayro for creating the Gen 9 base mod. Without it, this would not have been possible.
Heartfelt thanks to everyone from the Reborn Evolved Discord that helped me learn and figure things out. 
Special thanks to crtolu/grp on Discord for helping pretty much around the clock and pointing out very important things for me to pay attention to, such as an option to treat Shadow Pokémon during Chapter 10-13.
Make sure you check out their mod, "Rejuvenation Extreme" here: 
    https://www.rebornevo.com/forums/topic/78867-rejuvenation-extreme-completed-more-legendaries-custom-music-custom-abilities-custom-events-fights-gen9/


Description:
- This mod does NOT change the existing story. It adds no own story, it is purely meant as an addition to the vanilla game(plus minus whatever other mods you want to use.)
- This mod adds encounters for the new Pokemon introduced in Generation 9 to Pokemon Rejuvenation.
- The creatures are added in various areas throughout the game, such as cities, routes, caves, and other locations.
- This mod is intended to be a "sane" way to add the new Pokemon to the game, meaning that it does not add them in every single area, but rather in areas that make sense for their type, location and strength.
- All Paradox Pokemon can be encountered as Shadow Pokemon in several battles. They have been added to "minibosses", such as Xen Executives.
    - In all cases, the Paradox mons were simply "added", giving some Trainers illegal teams with 7+ Pokémon. I suppose this ups the difficulty.
- The goal is to provide a balanced and coherent experience, while still allowing players to get every creature in due time.


Compatibility:
The mod was created using V13.5.7 of the game together with the "Gen 9 Base Mod v0.85" and is intended to be used with them. 
There is no guarantee that it will function on other versions of the game.
It will not function without the "Gen 9 Base Mod".
If you do not have the Gen 9 Base Mod, you can find it here: 
    https://www.rebornevo.com/forums/topic/72534-rejuv-135-gen-9-mod-base-open-beta/
If it does end up causing issues with new game updates, I will try to fix it as I have time.
The mod can be used for new games or for existing saves.
For existing saves, you can simply go back to old areas to get the new wild encounters.
    - However, you will not be able to catch the Shadow Paradox Pokémon if you have already beaten the battle they appear in.



Wild_Pokemon_Locations:

The data is presented as follows:
[------------------------------------------]
### Area Name (Internal Area ID)
- Added Pokemon Name (Encounter Condition)
[------------------------------------------]

Additionally, the data is presented chronologically, meaning that the first area listed is the first area you can encounter a new creature in. It then follows the game progression.

--- Grass encounters are determined by time of day, being Morning, Day and Night. "All" indicates that a creature can be encountered during any of these times. This also counts for caves.
--- Unique requirements such as "Rock Smash" or "Headbutt" are also noted.
--- Pokemon that can be encountered in water are noted as "Water", while those that can be encountered with a fishing rod are noted as "Old Rod", "Good Rod" or "Super Rod".
--- The encounter chance for pretty much every new creature has been set to 10% or 5%, depending on how many were added per area.
    - To make sure the encounter table doesn't get messed up, the old highest encounter chance pokemon had their encounter chance reduced by that number.
    - For example, adding a Flamigo to Sheridan Village with a 10% encounter chance, I lowered the encounter chance for Zigzagoon from 20% to 10%.
    - This was the fastest, easiest and sanest way to give the new creatures a reasonable chance to appear, without having to mess with the encounter tables too much.
--- Encounters have been added up to Level 57 Areas. Maps after that do not contain any Generation 9 creatures as by that point, the player will have had the chance to catch every creature introduced.
    - Adding them to further maps would have taken quite a bit more time, and I couldn not think of a good reason to do it.


### East Gearen City (58)
- Added Tarountula (All)
- Added Tandemaus (All)

### East Gearen City (59)
- Added Tarountula (All)
- Added Tandemaus (All)

### Gearen Alleyway (20)
- Added Tarountula (All)
- Added Tandemaus (All)
- Added Maschiff (All)

### Chrisola Hotel Rooftop (228)
- Added Tarountula (All)
- Added Pawmi (Morning, Day)
- Added Fidough (Morning, Day)

### Gearen Park (24)
- Added Smoliv (Morning, Day)
- Added Fidough (Morning, Day)

### Abandoned Sewers (55)
- Added Maschiff (All)
- Added Shroodle (All)

### Route 1 (5)
- Added Lechonk (All)
- Added Wattrell (Morning, Day)

### Goldenwood Forest (25, 50)
- Added Tarountula (All)
- Added Smoliv (All)
- Added Tamdemaus (All)

### Goldenwood Cave (8)
- Added Nymble (All)

### Route 2 (199)
- Added Veluza (Water)
- Added Finizen (Good Rod)
- Added Spidops (Headbutt)
- Added Toedscool (Morning. Day)
- Added Maschiff (Night)

### Gemstream Mine (133)
- Added Glimmet (All + Rock Smash)
- Added Nacli (Rock Smash)

### Amethyst Cave (159, 161, 184, 4)
- Added Glimmet (All)

### Amethyst Depths (77, 109)
- Added Glimmet (All)

### Sheridan Village (423)
- Added Flamigo (All)

### Sheridan Arena (424)
- Added Pawmo (All)

### Amethyst Grotto (488)
- Added Tinkatink (All)
- Added Tadbulb (All)

### Carotos Mountain (119)
- Added Nacli (All)
- Added Klawfl (All)

### Spring of Purification (206)
- Added Smoliv (All)
- Added Squawkabilly (All)
- Added Wiglett (All)
- Added Finizen (Good Rod)
- Added Tatsugiri (Super Rod)

### Chrysalis Courtyard (390, 391)
- Added Dachsbun (All)
- Added Dolliv (All)

### River's End (433)
- Added Flittle (All)
- Added Toedscool (All)
- Added Capsakid (All)

### Route 3 (67, 69, 71)
- Added Capsakid (All)
- Added Kilowattrel (All) 
- Added Rellor (All)
- Added Tatsugiri (Good Rod)

### Mirage Woods (149)
- Added Lokix (All)
- Added Squawkabilly (All)
- Added Sinistcha (All)
- Added Flittle (All)

### Phasial Cave (97)
- Added Glimmet (All)
- Added Orthworm (All)
- Added Nacklstack (All)

### Goldenleaf Town (82)
- Added Clodsire (All, Old Rod, Good Rod)
- Added Toedscruel (Morning, Day)
- Added Bramblin (All)
- Added Gimmighoul (All)

### Wispy Ruins (489)
- Added Gimmighoul (All)
- Added Sinistcha (All)
- Added Greavard (All)

### Forgotten Path (91)
- Added Greavard (Night)
- Added Sinistcha (Night)
- Added Gimmighoul (All)
- Added Mabostiff (Morning, Day)
- Added Veluza (Water, Good Rod)
- Added Dondozo (Super Rod)

### Wispy Path (95)
- Added Houndstone (All)
- Added Mabostiff (All)
- Added Veluza (Good Rod)

### Goldenwood Forest (321)
- Added Dolliv (All)
- Added Scovillain (All)
- Added Dudunsparce (All)

### Forsaken Laboratory (403)
- Added Clodsire (All)
- Added Rellor (All)
- Added Cyclizar (All)

### Backstage Theatre (401)
- Added Houndstone (All)
- Added Grafaiai (All)

### Wispy Chasm (12)
- Added Grafaiai (All)
- Added Houndstone (All)

### Route 4 (106, 115, 129, 130, 132, 166, 167)
- Added Kilowattrel (All)
- Added Bombirdier (All)
- Added Farigiraf (All)
- Added Bellibolt (All)
- Added Veluza (Water)

### Akuwa Town (13)
- Added Wugtrio (All)
- Added Finizen (Good Rod)
- Added Palafin (Super Rod)
- Added Veluza (Water, Old Rod)
- Added Dondozo (Good Rod)

### Blacksteeple Castle (435)
- Added Tinkatuff (All)
- Added Espartha (All)
- Added Flamigo (All)

### Blacksteeple Quarry (436)
- Added Nacklstack (All)
- Added Orthworm (All)
- Added Glimmora (All)

### Blacksteeple Garden (437)
- Added Scovillain (All)
- Added Flamigo (All)
- Added Farigiraf (All)

### Terajuma Shipyard (207)
- Added Wugtrio (All)
- Added Veluza (Water, Old Rod, Good Rod)
- Added Dondozo (Super Rod)
- Added Nacklstack (Rock Smash)

### Terajuma Jungle (210)
- Added Veluza (Water, Old Rod, Good Rod)
- Added Arboliva (Morning, Day)
- Added Spidops (Night)
- Added Lokix (All)
- Added Squawkabilly (Morning)

### Kakori Village (298)
- Added Veluza (Water, Old Rod, Good Rod)
- Added Klawf (Morning, Day)
- Added Capsakid (Morning, Day)
- Added Toedscruel (All)
- Added Clodsire (Night)
- Added Farigiraf (Morning, Day)

### Mynori Sea (299)
- Added Wugtrio (All)
- Added Veluza (Water, Old Rod, Good Rod)
- Added Finizen (Old Rod, Good Rod)
- Added Palafin (Super Rod)
- Added Tatsugiri (Good Rod)

### Deep Terajuma Jungle (208, 268)
- Added Capsakid (Morning, Day)
- Added Toedscruel (All)
- Added Grafaiai (All)
- Added Arboliva (Morning, Day)
- Added Lokix (Night)

### T. Excavation Site (183)
- Added Bellibolt (All)
- Added Pawmot (All)

### Temple Outskirts (406)
- Added Rabsca (All)
- Added Kilowattrel (All)

### Tyluric Temple (179, 181)
- Added Tinkaton (All)
- Added Cyclizar (All)

### Terajuma Beach (171)
- Added Wugtrio (All)
- Added Klawf (All)
- Added Dondozo (Good Rod)
- Added Palafin (Good Rod)
- Added Tatsugiri (Super Rod)

### Route 5 (301, 322)
- Added Kilowattrel (All)
- Added Klawf (All)
- Added Veluza (Water, Good Rod)
- Added Garganacl (All)
- Added Tatsugiri (Old Rod)

### Jynnobi Pass (173)
- Added Klawf (All)
- Added Clodsire (All)
- Added Palafin (Water)

### Mirimura Cave (174)
- Added Veluza (Water)
- Added Palafin (Old Rod)
- Added Dondozo (Old Rod)
- Added Espathra (All)
- Added Toedscruel (All)
- Added Brambleghast (All)

### Mt. Terajuma (295)
- Added Cetoddle (All)
- Added Frigibax (All)

### Route 11 (3, 100, 473)
- Added Tatsugiri (Water)
- Added Finizen (Water)
- Added Dondozo (Good Rod)
- Added Nacklstack (Rock Smash)

### Seabound Cave (480)
- Added Cetoddle (All)
- Added Frigibax (All)

### Magrodar Crater (213)
- Added Charcadet (All)

### Tower Cellar (344)
- Added Frigibax (All)
- Added Arctibax (All)

### Forest of Time
- Added Cetoddle (All)
- Added Cyclizar (All)

### Judicial District
- Added Pawmot (All)
- Added Cyclizar (All)

### Scholar District (257)
- Added Mabostiff (Night)
- Added Rabsca (Morning)
- Added Espartha (Day)

### Pyramid Grounds (606)
- Added Revavroom (All)
- Added Orthworm (All)

### Zone Zero (578)
- Added Tinkaton (All)





Paradox_Legendary_Pokemon_Locations:

Things_to_know:
- Every Paradox Pokemon has had it' catch rate set to 20.
- Since the Paradox Pokémon are incredibly strong and only found in these miniboss battles, I decided that a catchrate of 20 is adequate, after doing some testing.
- I played around for a bit, taking into consideration the Pokéballs the player will have at that point and after testing for numbers and feel, 20 was a solid value for the catch rate.
- What does 20 mean? It means that with a Great Ball, the baseline chance to catch one of these creatures at ~Lv.40 and 100% HP is about 8.8%. Ultra Balls are 10.2%.
- That's a decent enough chance to score a "lucky" catch first try. Just one instance of self damage from hyper mode raises the chance to catch it by 1.2%.
- So the longer the fight drags on, the easier it will be to catch it, without external influence.

    - In 2 cases, the mon was caught immediately.
    - In 1 cases, the mon was caught after 2 tries.
    - In 4 cases, the mon was caught after 3 tries.
    - In 4 cases, the mon was caught after 4 tries.
    - In 3 cases, the mon was caught after 5 tries.
    - In 1 cases, the mon was caught after 6 tries.
    - Not once in these 15 cases were 7+ tries needed.

- I was happy with this as I compared "balls thrown to catch" with "attacks used to faint". An average of 3-4 attacks to faint a mon seemed okay to me.

- And while this reduced the catch rate for some Paradox mons, which became harder to catch, it also increased it for others, making it easier.
        - For example, Scream Tail was made harder to catch since the catch rate was changed from 50 to 20.(About halved)
        - However, Walking Wake was made easier to catch since the catch rate was changed from 5 to 20.(quadrupled)

- Tl;dr:
        - Catch rate for all Paradox Mons was streamlined, to ensure the miniboss battles remain miniboss battles in terms of difficulty.
        - It was also to mitigate potential frustration that comes with trying to catch low catch rate mons.


### Flutter Mane - Terajuma
- Added to Xen Executive Geara ["Geara",:XENEXECUTIVE_3,3]
        - Replaces Alolan Marowak in the Legal Team Version!
        - Team size increased to 7 in the Illegal Team Version!

### Iron Treads/Great Tusk - Mt. Terajuma [Since you have to chose here, I've added both mons to both routes. To ensure you can catch both creatures, the only legal option was to replace 2 existing creatures.]
- Added Iron Treads/Great Tusk to Neved ["Neved",:XENEXECUTIVE_4,1]
        - Replaces Barbaracle and Vikavolt in the Legal Team Version!
        - Team size increased to 8 in the Illegal Team Version!
- Added Iron Treads/Great Tusk to Zetta ["Zetta",:XENEXECUTIVE_1,5]
        - Replaces Perrserker and Dragonair in the Legal Team Version!
        - Team size increased to 8 in the Illegal Team Version!

### Scream Tail - Terajuma being attacked
- Added Scream Tail to Madelis ["Madelis",:XENEXECUTIVE_2,2]
        - Replaces Florges in the Legal Team Version!
        - Team size increased to 7 in the Illegal Team Version!

### Iron Bundle - Church of Theolia("THAT" battle)
- Added Iron Bundle to Angie ["Angie",:LEADER_ANGIE,0]
        - Replaces Beartic in the Legal Team Version!
        - Team size increased to 7 in the Illegal Team Version!

### Brute Bonnet/Iron Hands - Valor Summit [This one was by far the most annoying to test, simply due to Melia killing stuff. Still, you have the option to catch both!]
- Added Iron Hands to Geara ["Geara",:XENEXECUTIVE_3,2]
        - Replaces Gyarados in the Legal Team Version!
        - Team size increased to 7 in the Illegal Team Version!
- Added Brute Bonnet to Zetta ["Zetta",:XENEXECUTIVE_1,8]
        - Replaces Absol in the Legal Team Version!
        - Team size increased to 7 in the Illegal Team Version!

### Iron Thorns/Iron Jugulis - Kristiline Help Quest (Infinite Potential)
- Added Iron Thorns to "???" ["???",:UNKNOWN_1,1]
        - Team size increased to 6 in both Versions!
- Added Iron Jugulis to "???" ["???",:UNKNOWN_1,0]
        - Team size increased to 6 in both Versions!

### Slither Wing - Karrina Story Encounter
- Added Slither Wing to Karrina ["Karrina",:GANGLEADER,1]
        - Team size increased to 6 in both Versions!

### Iron Valiant - Kakori Help Quests(Abnormal Phenomenon)
- Added to Mr. Hynde ["Mr. Hynde",:DIABOLICALGENIUS,0]
        - Team size increased to 6 in both Versions!

### Iron Moth - Terajuma being attacked
- Added Iron Moth to Neved ["Neved",:XENEXECUTIVE_4,2]

### Walking Wake/Raging Bolt - Neo East Gearen City Help Quest (Poke Ball Conundrum)
- Added Walking Wake to Deathwing Sonia ["Sonia",:XENDEATHWING_F,0]
        - Team size increased to 6 in both Versions!
- Added Raging Bolt to Deathwing Lupin ["Lupin",:XENDEATHWING_M,0]
        - Team size increased to 6 in both Versions!

### Iron Crown - Neo East Gearen City Help Quest (Forest Restoration)
- Added Iron Crown to Deathwing Danni ["Danni",:XENDEATHWING_M,0]
        - Team size increased to 6 in both Versions!

### Iron Leaves - Terajuma Island 12 Badge Quest
- Added Iron Leaves to Deathwing Darwin ["Darwin",:XENDEATHWING_M,0]
        - Team size increased to 6 in both Versions!

### Iron Boulder/Gouging Fire - Zone Zero
- Added Iron Boulder and Gouging Fire to Misfortune Duo Eli & Sharon ["Eli and Sharon",:MISFORTUNATEDUO,15]
        - Team size increased to 8 in oth Versions!
         -I did not want to do a "Legal Version" for this case, because I like the duo and wanted to let them have a chance to whopp the players ass.

























------------------------------------------------
------------------------------------------------
###This section can be ignored.
------------------------------------------------
------------------------------------------------

Dev Notes:

Obtaining HM02 Fly will serve as trigger to activate all Legendary Events aside from Miraidon and Koraidon.
        While I understand that having access to a variety of strong Pokémon can make the game easier, I still believe that they should be obtainable at a reasonable time in the story.
        This allows them to actually be used during the story and not just for post game activities. This is probably my personal bias speaking, but I see very little point in post-game legendaries.
                What purpose do they serve?
        I want to ensure that players have the opportunity to experience the story and catch these Pokémon in a way that feels natural and rewarding.
                Because of this, I've created Quests that will unlock after HM02 Fly is obtained.
                Each of these Quests will allow the player to catch a Legendary Pokémon after doing some puzzling and battling.